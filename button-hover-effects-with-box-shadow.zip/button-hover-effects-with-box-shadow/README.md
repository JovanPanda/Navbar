# Button hover effects with box-shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/BZaGyP](https://codepen.io/giana/pen/BZaGyP).

Making some basic animations with box-shadows. No extra elements or even pseudo elements required.

Check out <a href="https://codepen.io/collection/AObpre/">my button collection</a> for more.